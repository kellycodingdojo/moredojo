from django.shortcuts import render, redirect
from models import User, Books, Reviews, Authors
from django.contrib import messages
from django.db.models import Count
# Create your views here.
def index(request):
    return render(request, 'beltrev/index.html')

def register(request):
    if request.method == "POST":
        user = User.objects.register(request.POST)
        if 'errors' in user:
            for error in user['errors']:
                messages.error(request, error)
            return redirect('/')
        if 'theuser' in user:
            request.session['theuser'] = user['theuser']
            request.session['userid'] = user['userid']
            return redirect('/books')

def dash(request):
    context = {'top_three':Reviews.objects.all().order_by('-created_at')[:3],
    'all_revs':Reviews.objects.all()
    }
    return render(request, 'beltrev/dash.html', context)

def login(request):
    if request.method == "POST":
        user = User.objects.login(request.POST)
        if 'errors' in user:
            for error in user['errors']:
                messages.error(request, error)
                return redirect('/')
        if 'theuser' in user:
            request.session['theuser'] = user['theuser']
            request.session['userid'] = user['userid']
            return redirect('/books')

def add(request):
    context = {'authors':Authors.objects.all()}
    return render(request, 'beltrev/add.html', context)

def home(request):
    return redirect('/books')

def logout(request):
    del request.session['theuser']
    del request.session['userid']
    return redirect('/')

def new_book(request):
    if request.method == "POST":
        book = Books.objects.newadd(request.POST)
        restr = '/books/' + str(book['bookid'])
        return redirect(restr)

def users(request, id):
    context = {'user':User.objects.get(id=id)}
    context['tot_revs']=Reviews.objects.annotate(count=Count('review')).filter(user__id=context['user'].id)
    return render(request, 'beltrev/user.html', context)

def book(request, id):
    context={'book':Books.objects.get(id=id)}
    return render(request, 'beltrev/book.html', context)

def add_rev(request):
    if request.method == "POST":
        Reviews.objects.add(request.POST, request.session['userid'])
        return redirect('/books')

def delete(request, id):
    Reviews.objects.get(id=id).delete()
    return redirect('/books')

def delete_all(request):
    Reviews.objects.all().delete()
    User.objects.all().delete()
    Books.objects.all().delete()
    Authors.objects.all().delete()
    return redirect('/')
