from __future__ import unicode_literals
import bcrypt, re
from django.db import models

# Create your models here.
class UserManager(models.Manager):
    def register(self, postData):
        error_msgs = []
        email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

        try:
            if User.objects.get(email=postData['email']):
                error_msgs.append("Email already in use!")
        except:
            pass

        if len(postData['name']) < 2:
            error_msgs.append("Name is too short!")

        if len(postData['alias']) < 2:
            error_msgs.append("Alias is too short!")

        if not email_regex.match(postData['email']):
            error_msgs.append("Invalid email!")

        if len(postData['pass']) < 2:
            error_msgs.append("Password is too short!")

        if not postData['pass'] == postData['pass_conf']:
            error_msgs.append("Passwords do not match!")

        if error_msgs:
            return {'errors':error_msgs}
        else:
            hashed = bcrypt.hashpw(postData['pass'].encode(), bcrypt.gensalt())
            user = User.objects.create(email=postData['email'],name=postData['name'], alias=postData['alias'], password=hashed)
            return {'theuser':user.alias, 'userid': user.id}

    def login(self, postData):
        error_msgs = []
        password = bcrypt.hashpw(postData['pass'].encode(), bcrypt.gensalt())

        try:
            user = User.objects.get(email=postData['email'])
        except:
            error_msgs.append("Invalid user!")
            return {'errors':error_msgs}

        if not bcrypt.hashpw(postData['pass'].encode(), user.password.encode()) == user.password.encode():
            error_msgs.append("Wrong Password!")

        if error_msgs:
            return {'errors':error_msgs}
        else:
            return {'theuser':user.alias, 'userid':user.id}

class User(models.Model):
    email = models.CharField(max_length=255)
    name = models.CharField(max_length=45)
    alias = models.CharField(max_length=45)
    password = models.CharField(max_length=45)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class BookManager(models.Manager):
    def newadd(self, postData):
        error_msgs = []
        if len(postData['title']) < 1:
            error_msgs.append("No Title!")

        if error_msgs:
            return {'errors':error_msgs}
        else:
            if postData['author'] == '':
                author = Authors.objects.get(id=postData['authorb'])
            else:
                author = Authors.objects.create(name=postData['author'])
            book = Books.objects.create(title=postData['title'], author=author)
            Reviews.objects.create(review=postData['review'], rating=postData['rating'], book=Books.objects.get(id=book.id), user=User.objects.get(id=postData['userid']))
            return {'bookid':book.id}

class Authors(models.Model):
    name = models.CharField(max_length=45)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Books(models.Model):
    title = models.CharField(max_length=45)
    author = models.ForeignKey(Authors, related_name='books')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = BookManager()

class ReviewManager(models.Manager):
    def add(self, postData, userid):
        user = {'user': User.objects.get(id=userid)}
        book = {'book': Books.objects.get(id=postData['id'])}
        Reviews.objects.create(review=postData['review'], rating=postData['rating'], book=book['book'], user=user['user'])
        return

class Reviews(models.Model):
    review = models.TextField()
    rating = models.CharField(max_length=1)
    book = models.ForeignKey(Books, related_name="reviews")
    user = models.ForeignKey(User, related_name="reviews")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ReviewManager()

class BookManger(request):
    def addnew(self, postData):
        if len(postData['title']) < 1:
            error_msgs.append("NO Title!")

        if errors_msgs:
            return{'errros': error_msgs}
        else:
            if postData['author'] = '':
                author = Authors.objects.get(id=postData['authorb'])
            else:
                author = Authors.objects.create(name=postData['authorb'])
            book = Books.objects.create(review=postData['review']), 



    def newadd(self, postData):
        error_msgs = []
        if len(postData['title']) < 1:
            error_msgs.append("No Title!")

        if error_msgs:
            return {'errors':error_msgs}
        else:
            if postData['author'] == '':
                author = Authors.objects.get(id=postData['authorb'])
            else:
                author = Authors.objects.create(name=postData['author'])
            book = Books.objects.create(title=postData['title'], author=author)
            Reviews.objects.create(review=postData['review'], rating=postData['rating'], book=Books.objects.get(id=book.id), user=User.objects.get(id=postData['userid']))
            return {'bookid':book.id}